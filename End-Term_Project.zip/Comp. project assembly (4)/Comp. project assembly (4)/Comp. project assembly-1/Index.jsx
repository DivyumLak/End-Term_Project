import {React, useState } from 'react'
 
export default function App() {
  return (
      <div className="counter">
    <h1>React Counter</h1>
    <p className="counter__output"></p>
    <div className="btn__container">
      <button className="control__btn" >+</button>
      <button className="control__btn">-</button>
      <button className="reset">Reset</button>    
      <p className="counter__output"></p>
    </div>
  </div>
